import axios from 'axios';

// Create an instance of axios with the base URL for the backend
const api = axios.create({
    baseURL: 'http://localhost:5000' // Backend URL
});

// Function to register a new user
export const register = newUser => {
    return api.post('/users/register', {
        first_name: newUser.first_name,
        last_name: newUser.last_name,
        email: newUser.email,
        password: newUser.password
    })
    .then(response => {
        console.log('Registration successful');
        window.alert('Registration successful');
        return response;
    })
    .catch(err => {
        console.error('Registration Error:', err.response ? err.response.data : err.message);
        window.alert('Registration failed. Please try again.');
        throw err; // Ensure to handle this error in the component
    });
};

// Function to login a user
export const login = user => {
    return api.post('/users/login', {
        email: user.email,
        password: user.password
    })
    .then(response => {
        localStorage.setItem('usertoken', response.data.token);
        return response.data;
    })
    .catch(err => {
        console.error('Login Error:', err.response ? err.response.data : err.message);
        window.alert('Login failed. Please check your credentials and try again.');
        throw err; // Ensure to handle this error in the component
    });
};
