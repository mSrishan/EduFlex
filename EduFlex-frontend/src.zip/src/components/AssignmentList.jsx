import React from 'react';

function AssignmentList() {
  return (
    <div>
      <h1>Assignment List</h1>
      {/* Assignment list content goes here */}
    </div>
  );
}

export default AssignmentList;
